import { Component, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';

import { Subject, takeUntil } from 'rxjs';

import { CoachWorkoutsService } from '../../../../services/coach/coach-workouts/coach-workouts.service';
import { LanguageService } from '../../../../services/shared/language.service';
import { SHARED_IMPORTS } from '../../../shared/shared-imports';
import { Workout } from '../../../../models/workout.model';
import { WorkoutWithExercises } from '../../../../models/exercise.model';
import { AppCardComponent } from '../../../shared/components/app-card/app-card.component';
import { USER_MESSAGES } from '../../../../constants/user-messages';
import { AppSearchComponent } from '../../../../components/shared/components/app-search/app-search.component';
import { PaginationComponent } from '../../../../components/shared/components/pagination/pagination.component';
import { NewWorkoutComponent } from '../../operations/coach-workouts/coach-workout-new/new-workout.component';
import { AppButtonComponent } from '../../../../components/shared/components/app-button/app-button.component';

@Component({
  selector: 'app-coach-workouts',
  standalone: true,
  imports: [
    ...SHARED_IMPORTS,
    NewWorkoutComponent,
    AppCardComponent,
    AppSearchComponent,
    PaginationComponent,
    AppButtonComponent,
  ],
  templateUrl: './coach-workouts.component.html',
  styleUrls: ['./coach-workouts.component.css'],
})
export class WorkoutListComponent implements OnInit, OnChanges, OnDestroy {
  private readonly destroy$ = new Subject<void>();

  // ==========================================================
  // WORKOUTOK
  // ==========================================================

  workouts: Workout[] = [];

  // ==========================================================
  // ÚJ WORKOUT
  // ==========================================================

  newWorkout: Workout = {
    workoutName: '',
    description: '',
    durationMinutes: 0,
  };

  // ==========================================================
  // INPUT
  // ==========================================================

  @Input()
  programId?: number;

  @Input()
  userId: number = 1;

  // ==========================================================
  // ÜZENETEK
  // ==========================================================

  message: string = '';

  messageType: 'success' | 'error' | '' = '';

  // ==========================================================
  // ÚJ WORKOUT FORM
  // ==========================================================

  showNewWorkoutForm: boolean = false;

  // ==========================================================
  // LAPOZÁS
  // ==========================================================

  currentPage: number = 1;

  itemsPerPage: number = 4;

  totalPages: number = 1;

  // ==========================================================
  // KERESÉS
  // ==========================================================

  searchTerm: string = '';

  // ==========================================================
  // RENDEZÉS
  // ==========================================================

  sortDirection: 'asc' | 'desc' = 'asc';

  constructor(
    private coachWorkoutsService: CoachWorkoutsService,
    private languageService: LanguageService,
    private router: Router,
  ) {}

  // ==========================================================
  // INIT
  // ==========================================================

  ngOnInit(): void {
    this.languageService.language$.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.loadWorkouts();
    });
  }

  // ==========================================================
  // DESTROY
  // ==========================================================

  ngOnDestroy(): void {
    this.destroy$.next();

    this.destroy$.complete();
  }

  // ==========================================================
  // INPUT VÁLTOZÁS
  // ==========================================================

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['programId'] && !changes['programId'].firstChange) {
      this.loadWorkouts();
    }
  }

  // ==========================================================
  // WORKOUTOK BETÖLTÉSE
  // ==========================================================

  loadWorkouts(): void {

    this.coachWorkoutsService.getUniqueWorkoutsWithExercises().subscribe({
      next: (response) => {

        const res = response.data;

        this.workouts = (res ?? []).map((w: WorkoutWithExercises): Workout => ({
          id: w.id,

          workoutName: w.name ?? '',

          description: w.description ?? '',

          durationMinutes: w.durationMinutes,

          difficultyLevel: undefined,

          exercises: w.exercises ?? [],
        }));

        // Mindig az első oldalról indulunk.
        this.currentPage = 1;

        this.updatePagination();

      },

      error: (error) => {
        console.error('[CoachWorkouts] workout betöltési hiba:', error);

        this.workouts = [];

        this.currentPage = 1;

        this.totalPages = 1;

        this.setMessage('coachWorkouts.loadError', 'error');
      },
    });
  }

  // ==========================================================
  // SZŰRT ÉS RENDEZETT WORKOUTOK
  // ==========================================================

  get filteredWorkouts(): Workout[] {
    const search = this.searchTerm.trim().toLowerCase();

    const result = this.workouts.filter((workout: Workout): boolean => {
      const workoutName = workout.workoutName?.toLowerCase() ?? '';

      return workoutName.includes(search);
    });

    // ========================================================
    // RENDEZÉS WORKOUT NÉV SZERINT
    // ========================================================

    result.sort((a: Workout, b: Workout): number => {
      const nameA = a.workoutName?.trim().toLowerCase() ?? '';

      const nameB = b.workoutName?.trim().toLowerCase() ?? '';

      const comparison = nameA.localeCompare(nameB, this.languageService.getCurrentLanguage(), {
        sensitivity: 'base',
      });

      return this.sortDirection === 'asc' ? comparison : -comparison;
    });

    return result;
  }

  // ==========================================================
  // LAPOZÁS FRISSÍTÉSE
  // ==========================================================

  private updatePagination(): void {
    const workoutCount = this.filteredWorkouts.length;

    this.totalPages = Math.max(1, Math.ceil(workoutCount / this.itemsPerPage));

    if (this.currentPage > this.totalPages) {
      this.currentPage = this.totalPages;
    }
  }

  // ==========================================================
  // KERESÉS VÁLTOZÁSA
  // ==========================================================

  onSearchChange(): void {
    this.currentPage = 1;

    this.updatePagination();
  }

  // ==========================================================
  // RENDEZÉS VÁLTOZTATÁSA
  // ==========================================================

  toggleSort(): void {
    this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';

    this.currentPage = 1;

    this.updatePagination();
  }

  // ==========================================================
  // AKTUÁLIS OLDAL WORKOUTJAI
  // ==========================================================

  get pagedWorkouts(): Workout[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;

    return this.filteredWorkouts.slice(startIndex, startIndex + this.itemsPerPage);
  }

  // ==========================================================
  // KÖVETKEZŐ OLDAL
  // ==========================================================

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }

  // ==========================================================
  // ELŐZŐ OLDAL
  // ==========================================================

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }
  onPageChange(page: number): void {
    this.currentPage = page;
  }

  // ==========================================================
  // WORKOUT HOZZÁADÁSA
  // ==========================================================

  addWorkout(): void {
    if (this.programId === undefined || this.programId === null) {
      return;
    }

    this.newWorkout.programId = this.programId;

    this.coachWorkoutsService.addWorkout(this.newWorkout).subscribe({
      next: (res) => {
        if (res.done === true) {
          this.setMessage(res.message || 'coachWorkouts.addSuccess', 'success');

          this.newWorkout = {
            workoutName: '',
            description: '',
            durationMinutes: 0,
          };

          this.loadWorkouts();
        } else {
          this.setMessage(res.message || 'coachWorkouts.addError', 'error');
        }
      },

      error: () => {
        this.setMessage('coachWorkouts.addError', 'error');
      },
    });
  }

  // ==========================================================
  // WORKOUT SZERKESZTÉSE
  // ==========================================================

  editWorkout(workoutId: number | undefined, event: MouseEvent): void {
    event.stopPropagation();

    if (workoutId === undefined || workoutId === null || workoutId <= 0) {
      this.message = USER_MESSAGES.workoutClickError;

      return;
    }

    this.router.navigate([`/coach/workouts/${workoutId}/edit`]).catch((error) => {
      console.error('router.navigate hiba:', error);

      this.message = USER_MESSAGES.workoutClickError;
    });
  }

  // ==========================================================
  // ÚJ WORKOUT FORM KI/BE
  // ==========================================================

  toggleNewWorkout(): void {
    this.showNewWorkoutForm = !this.showNewWorkoutForm;
  }

  // ==========================================================
  // ÜZENET
  // ==========================================================

  private setMessage(msg: string, type: 'success' | 'error'): void {
    this.message = msg;

    this.messageType = type;

    setTimeout(() => {
      this.message = '';

      this.messageType = '';
    }, 4000);
  }

  // ==========================================================
  // ÚJ WORKOUT OLDAL
  // ==========================================================

  goToNewWorkout(): void {
    this.router.navigate(['/coach/workouts/new']);
  }
}
