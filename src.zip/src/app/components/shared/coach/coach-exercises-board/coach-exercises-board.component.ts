import {
  Component,
  OnInit,
  OnChanges,
  OnDestroy,
  SimpleChanges,
  Input,
  Output,
  EventEmitter,
  inject,
} from '@angular/core';

import { Subject, takeUntil } from 'rxjs';
import { AppSearchComponent } from '../../components/app-search/app-search.component';
import { ExerciseService } from '../../../../services/coach/coach-exercises/coach-exercises.service';
import { LanguageService } from '../../../../services/shared/language.service';
import { PaginationComponent } from '../../../../components/shared/components/pagination/pagination.component';
import { Exercise } from '../../../../models/exercise.model';
import { ApiResponse } from '../../../../models/backend-dto/common/api-response';
import { AppCardComponent } from '../../../../components/shared/components/app-card/app-card.component';
import { SHARED_IMPORTS } from '../../shared-imports';

@Component({
  selector: 'app-coach-exercises-board',
  standalone: true,
  imports: [...SHARED_IMPORTS, PaginationComponent, AppSearchComponent, AppCardComponent],
  styleUrl: './coach-exercises-board.component.css',
  templateUrl: './coach-exercises-board.component.html',
})
export class CoachExercisesBoardComponent implements OnInit, OnChanges, OnDestroy {
  private readonly destroy$ = new Subject<void>();

  private exerciseService = inject(ExerciseService);

  private languageService = inject(LanguageService);

  // ==========================================================
  // INPUT / OUTPUT
  // ==========================================================

  @Input()
  externalExercises: Exercise[] = [];

  @Input()
  externalSelectedExercises: Exercise[] = [];

  /**
   * Exercise-ek zárolása.
   *
   * true:
   *   meglévő workout → az exercise-ek nem módosíthatók.
   *
   * false:
   *   új workout → az exercise-ek szabadon
   *   kiválaszthatók és eltávolíthatók.
   */
  @Input()
  lockSelectedExercises = false;

  @Output()
  exercisesChange = new EventEmitter<Exercise[]>();

  // ==========================================================
  // ÁLLAPOT
  // ==========================================================

  exercises: Exercise[] = [];

  selectedExercises: Exercise[] = [];

  loading = false;

  message = '';

  messageType: 'success' | 'error' | 'info' | '' = '';

  // ==========================================================
  // KERESÉS
  // ==========================================================

  searchTerm = '';

  // ==========================================================
  // LAPOZÁS
  // ==========================================================

  exercisePage = 1;

  pageSize = 5;

  // ==========================================================
  // INIT
  // ==========================================================

  ngOnInit(): void {
    this.loadExercises();

    // ==========================================================
    // NYELVVÁLTÁS
    // ==========================================================

    this.languageService.language$.pipe(takeUntil(this.destroy$)).subscribe(() => {
      this.loadExercises();
    });
  }

  // ==========================================================
  // INPUT VÁLTOZÁSOK
  // ==========================================================

  ngOnChanges(changes: SimpleChanges): void {
    /**
     * Ha a szülő selectedExercises tömbje változik
     * (például workout kiválasztásakor vagy resetnél),
     * tükrözzük a változást.
     */
    if (changes['externalSelectedExercises']) {
      if (this.externalSelectedExercises?.length) {
        this.selectedExercises = [...this.externalSelectedExercises];
      } else {
        this.selectedExercises = [];
      }
    }

    /**
     * Ha a szülő exercise listát ad át,
     * azt használjuk.
     */
    if (changes['externalExercises'] && this.externalExercises) {
      this.exercises = [...this.externalExercises];

      this.exercisePage = 1;

      /**
       * A szülőnek visszaküldjük az aktuális
       * kiválasztott exercise-eket.
       */
      this.exercisesChange.emit([...this.selectedExercises]);
    }
  }

  // ==========================================================
  // EXERCISE-EK BETÖLTÉSE
  // ==========================================================

  loadExercises(): void {
    this.loading = true;

    this.message = '';
    this.messageType = '';

    this.exerciseService.getAllExercises().subscribe({
      next: (response: ApiResponse<Exercise[]>) => {
        this.loading = false;

        this.exercises = response.data ?? [];

        this.exercisePage = 1;

        if (!this.exercises.length) {
          this.message = 'coachExercisesBoard.noExercises';
          this.messageType = 'info';
        } else {
          this.message = '';
          this.messageType = '';
        }
      },

      error: () => {
        this.loading = false;

        this.exercises = [];

        this.message = 'coachExercisesBoard.loadError';
        this.messageType = 'error';
      },
    });
  }

  // ==========================================================
  // KERESÉS
  // ==========================================================

  onSearchChange(): void {
    this.exercisePage = 1;
  }

  clearSearch(): void {
    this.searchTerm = '';

    this.exercisePage = 1;
  }

  get filteredExercises(): Exercise[] {
    const search = this.searchTerm.trim().toLowerCase();

    if (!search) {
      return this.exercises;
    }

    return this.exercises.filter((exercise) => {
      const name = exercise.name?.toLowerCase() ?? '';
      const description = exercise.description?.toLowerCase() ?? '';
      const muscleGroup = exercise.muscleGroup?.toLowerCase() ?? '';
      const equipment = exercise.equipment?.toLowerCase() ?? '';

      return (
        name.includes(search) ||
        description.includes(search) ||
        muscleGroup.includes(search) ||
        equipment.includes(search)
      );
    });
  }

  // ==========================================================
  // LAPOZÁS
  // ==========================================================

  get pagedExercises(): Exercise[] {
    const exercises = this.filteredExercises;

    const start = (this.exercisePage - 1) * this.pageSize;

    return exercises.slice(start, start + this.pageSize);
  }

  get totalExercisePages(): number {
    return Math.ceil(this.filteredExercises.length / this.pageSize);
  }

  nextExercisePage(): void {
    if (this.exercisePage < this.totalExercisePages) {
      this.exercisePage++;
    }
  }

  prevExercisePage(): void {
    if (this.exercisePage > 1) {
      this.exercisePage--;
    }
  }

  // ==========================================================
  // EXERCISE KIVÁLASZTÁS
  // ==========================================================

  isExerciseSelected(ex: Exercise): boolean {
    return !!this.selectedExercises.find((exercise) => exercise.id === ex.id);
  }

  // ==========================================================
  // EXERCISE KIVÁLASZTÁS MÓDOSÍTÁSA
  // ==========================================================

  toggleExerciseSelection(ex: Exercise, checked: boolean): void {
    /**
     * Meglévő workout esetén az exercise lista
     * teljesen zárolva van.
     *
     * Ez egy második védelmi szint:
     * még akkor sem módosítjuk az állapotot,
     * ha valamilyen módon meghívódna ez a metódus.
     */
    if (this.lockSelectedExercises) {
      this.message = 'coachExercisesBoard.exercisesLocked';
      this.messageType = 'info';

      return;
    }

    // ----------------------------------------------------------
    // ÚJ WORKOUT
    // ----------------------------------------------------------

    if (checked) {
      if (!this.selectedExercises.find((exercise) => exercise.id === ex.id)) {
        this.selectedExercises.push(ex);
      }
    } else {
      this.selectedExercises = this.selectedExercises.filter((exercise) => exercise.id !== ex.id);
    }

    /**
     * Csak új workout esetén jutunk ide,
     * ezért itt biztonságosan jelezhetjük
     * a szülőnek a változást.
     */
    this.exercisesChange.emit([...this.selectedExercises]);
  }

  // ==========================================================
  // CHECKBOX CHANGE
  // ==========================================================

  onCheckboxChange(ex: Exercise, event: Event): void {
    /**
     * Meglévő workout esetén nincs módosítás.
     */
    if (this.lockSelectedExercises) {
      return;
    }

    const target = event.target as HTMLInputElement;

    this.toggleExerciseSelection(ex, target.checked);
  }

  // ==========================================================
  // DESTROY
  // ==========================================================

  ngOnDestroy(): void {
    this.destroy$.next();

    this.destroy$.complete();
  }
}
