import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { TranslatePipe } from '@ngx-translate/core';

import { MessageComponent } from './message/message.component';
import { PaginationComponent } from '../../components/shared/components/pagination/pagination.component';
import { BackButtonComponent } from '../shared/components/back-button/back-button.component';
import { AppButtonComponent } from '../../components/shared/components/app-button/app-button.component';
import { AppCardComponent } from '../../components/shared/components/app-card/app-card.component';
import { FormFieldComponent } from './components/form-field/form-field.component';
import { AppIconComponent } from './components/app-icon/app-icon.component';

export const SHARED_IMPORTS = [
  CommonModule,
  RouterModule,
  FormsModule,
  TranslatePipe,
  MessageComponent,
  BackButtonComponent,
  PaginationComponent,
  AppButtonComponent,
  AppCardComponent,
  FormFieldComponent,
  AppIconComponent,
];
