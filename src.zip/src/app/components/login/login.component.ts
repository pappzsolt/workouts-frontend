import type { LoginResponse } from '../../models/auth-model';

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth/auth.service';
import { catchError, of } from 'rxjs';
import { Router } from '@angular/router';
import { USER_MESSAGES } from '../../constants/user-messages';
import { SHARED_IMPORTS } from '../shared/shared-imports';
import { LanguageSelectorComponent } from '../shared/language/language-selector.component';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [...SHARED_IMPORTS, ReactiveFormsModule, LanguageSelectorComponent],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage = '';
  loading = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  onSubmit(event?: Event) {
    if (event) event.preventDefault();

    if (this.loginForm.invalid) {
      this.errorMessage = USER_MESSAGES.required;
      return;
    }

    const { username, password } = this.loginForm.value;
    this.loading = true;
    this.errorMessage = '';

    this.authService
      .login(username, password)
      .pipe(
        catchError((err) => {
          console.error('Login hiba:', err);
          this.errorMessage = USER_MESSAGES.userOrPassFailed;
          this.loading = false;
          return of(null);
        }),
      )
      .subscribe((res: LoginResponse | null) => {
        this.loading = false;

        if (res) {

          const role = this.authService.getUserRole() ?? '';

          if (role.includes('ROLE_ADMIN')) {
            this.router.navigate(['/admin/dashboard']);
          } else if (role.includes('ROLE_COACH')) {
            this.router.navigate(['/coach/dashboard']);
          } else if (role.includes('ROLE_USER')) {
            this.router.navigate(['/user/dashboard']);
          } else {
            this.router.navigate(['/login']);
          }
        }
      });
  }
}
