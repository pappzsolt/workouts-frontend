import { Routes } from '@angular/router';

import { LoginComponent } from './components/login/login.component';
import { LoginLayoutComponent } from './layouts/login-layout/login-layout.component';
import { LayoutComponent } from './layouts/default-layout/layout.component';
import { UserProgramStatisticsComponent } from './components/user-dashboard/operations/program-statistics/program-statistics.component';
import { AdminDashboardComponent } from './components/admin-dashboard/dashboard/admin-dashboard.component';
import { AdminListUsersComponent } from './components/admin-dashboard/operations/admin-list-users/admin-list-users.component';
import { MemberSearchComponent } from './components/admin-dashboard/operations/user-search/member-search.component';
import { ChoiceUserNewComponent } from './components/admin-dashboard/operations/choice-user-new/choice-user-new.component';
import { ChoiceUserEditComponent } from './components/admin-dashboard/operations/choice-user-edit/choice-user-edit.component';
import { CoachNewComponent } from './components/admin-dashboard/operations/coach-new/coach-new.component';
import { UserNewComponent } from './components/admin-dashboard/operations/user-new/user-new.component';
import { CoachEditComponent } from './components/admin-dashboard/operations/coach-edit/coach-edit.component';
import { UserEditComponent } from './components/admin-dashboard/operations/user-edit/user-edit.component';
import { AssignWorkoutsExercisesComponent } from './components/coach-dashboard/operations/assign-workouts-exercises/assign-workouts-exercises.component';
import { CoachDashboardComponent } from './components/coach-dashboard/dashboard/coach-dashboard.component';
import { CoachProfileComponent } from './components/coach-dashboard/operations/coach-profile/coach-profile.component';
import { ExerciseControllerComponent } from './components/coach-dashboard/operations/coach-exercises/coach-exercises.component';
import { CoachExerciseEditComponent } from './components/coach-dashboard/operations/coach-exercises/coach-exercise-edit/coach-exercise-edit.component';
import { CoachNewProgramComponent } from './components/coach-dashboard/operations/coach-programs/coach-new-program/coach-new-program.component';
import { CoachProgramComponent } from './components/coach-dashboard/operations/coach-programs/coach-program/coach-program.component';
import { CoachProgramEditComponent } from './components/coach-dashboard/operations/coach-programs/coach-program-edit/coach-program-edit.component';
import { CoachWorkoutEditComponent } from './components/coach-dashboard/operations/coach-workouts/coach-workout-edit/coach-workout-edit.component';
import { CoachProgramBuilderComponent } from './components/coach-dashboard/operations/coach-program-builder/coach-program-builder.component';

import { UserDashboardComponent } from './components/user-dashboard/dashboard/user-dashboard.component';
import { UserProfileComponent } from './components/user-dashboard/operations/user-profile/user-profile.component';
import { UserMyProgramsComponent } from './components/user-dashboard/operations/user-my-programs/user-my-programs.component';
import { WorkoutsComponent } from './components/user-dashboard/operations/user-workouts/workouts.component';
import { UserExercisesComponent } from './components/user-dashboard/operations/user-exercises/user-exercises.component';
import { UserExerciseDetailComponent } from './components/user-dashboard/operations/user-exercises/user-exercises-detail/user-exercises-detail.component';
import { UserWorkoutsCalendarComponent } from './components/user-dashboard/operations/user-workouts-calendar/user-workouts-calendar.component';

import { authGuard } from './guards/auth.guard';
import { roleGuard } from './guards/role.guard';

export const routes: Routes = [
  // ============================================================
  // LOGIN
  // ============================================================
  {
    path: '',
    component: LoginLayoutComponent,
    children: [
      {
        path: 'login',
        component: LoginComponent,
      },
      {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
      },
    ],
  },

  // ============================================================
  // ADMIN
  // ============================================================
  {
    path: 'admin',
    component: LayoutComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      roles: ['ROLE_ADMIN'],
    },
    children: [
      {
        path: 'dashboard',
        component: AdminDashboardComponent,
      },

      {
        path: 'users',
        component: AdminListUsersComponent,
      },

      {
        path: 'users/search',
        component: MemberSearchComponent,
      },

      {
        path: 'choice-users/edit',
        component: ChoiceUserEditComponent,
      },

      {
        path: 'choice-users/new',
        component: ChoiceUserNewComponent,
      },

      {
        path: 'users/new',
        component: UserNewComponent,
      },

      {
        path: 'coach/new',
        component: CoachNewComponent,
      },

      {
        path: 'coach/edit',
        component: CoachEditComponent,
      },

      {
        path: 'users/edit',
        component: UserEditComponent,
      },

      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
      },

      {
        path: '**',
        redirectTo: 'dashboard',
      },
    ],
  },

  // ============================================================
  // COACH
  // ============================================================
  {
    path: 'coach',
    component: LayoutComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      roles: ['ROLE_COACH'],
    },
    children: [
      {
        path: 'dashboard',
        component: CoachDashboardComponent,
      },

      {
        path: 'profile',
        component: CoachProfileComponent,
      },

      {
        path: 'exercises',
        component: ExerciseControllerComponent,
      },

      // ÚJ PROGRAM BUILDER
      {
        path: 'program-builder',
        component: CoachProgramBuilderComponent,
      },

      {
        path: 'programs',
        component: CoachProgramComponent,
      },

      {
        path: 'programs/:id/workouts',
        component: AssignWorkoutsExercisesComponent,
      },

      {
        path: 'programs/new',
        component: CoachNewProgramComponent,
      },

      {
        path: 'programs/:id/edit',
        component: CoachProgramEditComponent,
      },

      {
        path: 'exercises/:id/edit',
        component: CoachExerciseEditComponent,
      },

      {
        path: 'workouts/:id/edit',
        component: CoachWorkoutEditComponent,
      },
      {
        path: 'assign-workouts-exercises',
        component: AssignWorkoutsExercisesComponent,
      },
      {
        path: 'workouts/new',
        loadComponent: () =>
          import('./components/coach-dashboard/operations/coach-workouts/coach-workout-new/new-workout.component').then(
            (m) => m.NewWorkoutComponent,
          ),
      },

      {
        path: 'exercises/new',
        loadComponent: () =>
          import('./components/coach-dashboard/operations/coach-exercises/coach-exercise-new/new-exercise.component').then(
            (m) => m.NewExerciseComponent,
          ),
      },

      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
      },

      {
        path: '**',
        redirectTo: 'dashboard',
      },
    ],
  },

  // ============================================================
  // USER
  // ============================================================
  {
    path: 'user',
    component: LayoutComponent,
    canActivate: [authGuard, roleGuard],
    data: {
      roles: ['ROLE_USER'],
    },
    children: [
      {
        path: 'dashboard',
        component: UserDashboardComponent,
      },

      {
        path: 'profile',
        component: UserProfileComponent,
      },

      {
        path: 'my-programs',
        component: UserMyProgramsComponent,
      },

      {
        path: 'program-statistics',
        component: UserProgramStatisticsComponent,
      },
      {
        path: 'workouts',
        component: UserWorkoutsCalendarComponent,
      },

      {
        path: 'programs/:id/workouts',
        component: WorkoutsComponent,
      },

      {
        path: 'workouts/:workoutId/exercises',
        component: UserExercisesComponent,
      },

      {
        path: 'workouts/:workoutId/exercises/:exerciseId',
        component: UserExerciseDetailComponent,
      },

      {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full',
      },

      {
        path: '**',
        redirectTo: 'dashboard',
      },
    ],
  },

  // ============================================================
  // ROOT
  // ============================================================
  {
    path: '**',
    redirectTo: 'login',
  },
];
